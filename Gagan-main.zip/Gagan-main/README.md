# Gagan
Trump trades is a real-money gaming app and website that offers a variety of casual games, prediction games, lottery-style draws, and casino-inspired options. The platform is specifically designed for the Indian market, supporting local payment systems like UPI, Paytm, PhonePe, and direct bank transfers.
